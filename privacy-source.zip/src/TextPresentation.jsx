
import { visualPolicy } from "./data/policyData.js";
import "./TextPresentation.css";

export default function TextPresentation() {
  const categories = visualPolicy.categories || [];

  return (
    <main className="text-policy-page">
      <header className="text-policy-header">
        <p className="text-policy-label">
          TEXT PRIVACY EXPLANATION
        </p>

        <h1>{visualPolicy.company} Privacy Policy</h1>

        <p className="text-policy-introduction">
          {visualPolicy.introduction ||
            "A clear, text-based explanation of the privacy policy."}
        </p>

        <p className="text-policy-description">
          This text version explains the same ten privacy
          categories shown in the visual infographic.
          Each section describes what Spotify says about
          collecting, using, sharing, and protecting
          personal information.
        </p>
      </header>

      <div className="text-policy-content">
        {categories.map((category, index) => (
          <section
            key={category.id}
            className="text-policy-section"
          >
            <p className="text-policy-section-number">
              SECTION {String(index + 1).padStart(2, "0")}
            </p>

            <h2>{category.title}</h2>

            <p className="text-policy-summary">
              {category.summary}
            </p>

            <h3>Key Points</h3>

            <ul>
              {(category.bullets || []).map(
                (bullet, bulletIndex) => (
                  <li key={bulletIndex}>
                    {bullet}
                  </li>
                )
              )}
            </ul>

            <h3>Detailed Explanation</h3>

            <p className="text-policy-details">
              {category.details ||
                "Additional information is not available yet."}
            </p>
          </section>
        ))}
      </div>

      <footer className="text-policy-footer">
        <h2>Read the Original Privacy Policy</h2>

        <p>
          This page is a simplified explanation of
          Spotify's privacy policy. For the complete
          legal wording, visit the official policy.
        </p>

        <a
          href="https://www.spotify.com/us/legal/privacy-policy/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Read Spotify's Original Privacy Policy ↗
        </a>
      </footer>
    </main>
  );
}
