
import { useEffect, useRef, useState } from "react";
import { visualPolicy } from "./data/policyData.js";
import "./AudioPresentation.css";

const SPEEDS = [0.75, 1, 1.25, 1.5, 1.75, 2];
const categories = visualPolicy.categories || [];

function clean(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function makeConversation(category, index) {
  if (!category) return [];

  const title = clean(category.title);
  const summary = clean(category.summary);
  const details = clean(category.details);
  const bullets = (category.bullets || []).map(clean).filter(Boolean);

  const lines = [
    {
      speaker: "host",
      text: `Hello, and welcome to our Spotify Privacy Policy podcast. Today, we're discussing section ${index + 1}: ${title}.`,
      pause: 900,
    },
    {
      speaker: "guest",
      text: "Thanks for having me. Let's explain what this means for someone who uses Spotify.",
      pause: 650,
    },
  ];

  if (summary) {
    lines.push({
      speaker: "host",
      text: `Let's start with the main idea. ${summary}`,
      pause: 850,
    });
  }

  if (bullets.length) {
    lines.push({
      speaker: "guest",
      text: "That's helpful. What are the most important things people should know?",
      pause: 600,
    });

    bullets.forEach((bullet, i) => {
      lines.push({
        speaker: "host",
        text: `${["First", "Next", "Also", "Finally"][Math.min(i, 3)]}, ${bullet.charAt(0).toLowerCase()}${bullet.slice(1).replace(/[.!?]+$/, "")}.`,
        pause: 550,
      });
    });
  }

  if (details && details.toLowerCase() !== summary.toLowerCase()) {
    lines.push({
      speaker: "guest",
      text: "Could you explain that in a little more detail?",
      pause: 600,
    });

    lines.push({
      speaker: "host",
      text: details,
      pause: 950,
    });
  }

  lines.push(
    {
      speaker: "guest",
      text: "That makes the policy much easier to understand. Thanks for explaining it.",
      pause: 650,
    },
    {
      speaker: "host",
      text: "You're welcome. Remember, this is a simplified explanation. You can read Spotify's original privacy policy for the complete details.",
      pause: 300,
    }
  );

  return lines;
}

function chooseVoices(voices) {
  const english = voices.filter((v) =>
    v.lang?.toLowerCase().startsWith("en")
  );

  const available = english.length ? english : voices;

  const avoid = [
    "bad news", "good news", "bells", "boing",
    "bubbles", "whisper", "zarvox", "trinoids",
    "organ", "cellos", "hysterical", "albert",
    "bahh", "deranged", "junior", "kathy",
    "princess", "ralph",
  ];

  const usable = available.filter(
    (v) => !avoid.some((word) => v.name.toLowerCase().includes(word))
  );

  const pool = usable.length ? usable : available;

  const hostNames = [
    "samantha", "ava", "allison", "jenny",
    "zoe", "victoria", "karen", "moira",
  ];

  const guestNames = [
    "daniel", "alex", "oliver", "aaron",
    "tom", "arthur", "rishi", "fred",
  ];

  function score(voice, preferred) {
    const name = voice.name.toLowerCase();
    const rank = preferred.findIndex((n) => name.includes(n));

    let points = rank >= 0 ? 120 - rank * 8 : 0;

    if (name.includes("premium")) points += 50;
    if (name.includes("enhanced")) points += 40;
    if (name.includes("natural")) points += 30;
    if (voice.localService) points += 10;
    if (voice.lang === "en-US") points += 12;
    if (voice.lang === "en-GB") points += 10;

    return points;
  }

  const host = [...pool].sort(
    (a, b) => score(b, hostNames) - score(a, hostNames)
  )[0] || null;

  const guest = [...pool]
    .filter((v) => v.voiceURI !== host?.voiceURI)
    .sort((a, b) => score(b, guestNames) - score(a, guestNames))[0] || host;

  return { host, guest };
}

export default function AudioPresentation() {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [wordOffset, setWordOffset] = useState(0);

  const sessionRef = useRef(0);
  const wordOffsetRef = useRef(0);
  const speedRef = useRef(1);
  const voicesRef = useRef({ host: null, guest: null });
  const timerRef = useRef(null);
  const pendingRef = useRef(null);
  const pauseStartedRef = useRef(0);
  const remainingRef = useRef(0);
  const playingRef = useRef(false);
  const pausedRef = useRef(false);

  const selectedCategory = categories[selectedIndex];
  const conversation = makeConversation(selectedCategory, selectedIndex);

  const segments = conversation.map((line) => ({
    ...line,
    words: line.text.split(/\s+/).filter(Boolean),
  }));

  const totalWords = segments.reduce(
    (sum, segment) => sum + segment.words.length,
    0
  );

  function clearTimer() {
    if (timerRef.current !== null) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }

    pendingRef.current = null;
    remainingRef.current = 0;
  }

  function stopSpeech() {
    sessionRef.current += 1;
    clearTimer();

    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }

    playingRef.current = false;
    pausedRef.current = false;
    setIsPlaying(false);
    setIsPaused(false);
  }

  function locateWord(offset) {
    let base = 0;

    for (let i = 0; i < segments.length; i++) {
      const count = segments[i].words.length;

      if (offset < base + count) {
        return {
          index: i,
          local: offset - base,
          base,
        };
      }

      base += count;
    }

    return { index: 0, local: 0, base: 0 };
  }

  function speakFrom(offset, playbackSpeed = speedRef.current) {
    if (
      !segments.length ||
      !("speechSynthesis" in window) ||
      !("SpeechSynthesisUtterance" in window)
    ) {
      return;
    }

    sessionRef.current += 1;
    const session = sessionRef.current;

    clearTimer();
    window.speechSynthesis.cancel();

    voicesRef.current = chooseVoices(
      window.speechSynthesis.getVoices()
    );

    const safeOffset = Math.max(
      0,
      Math.min(offset, Math.max(0, totalWords - 1))
    );

    wordOffsetRef.current = safeOffset;
    setWordOffset(safeOffset);

    playingRef.current = true;
    pausedRef.current = false;
    setIsPlaying(true);
    setIsPaused(false);

    const start = locateWord(safeOffset);

    function finish() {
      if (session !== sessionRef.current) return;

      playingRef.current = false;
      pausedRef.current = false;
      wordOffsetRef.current = 0;

      setIsPlaying(false);
      setIsPaused(false);
      setWordOffset(0);
    }

    function waitThenContinue(milliseconds, callback) {
      if (session !== sessionRef.current) return;

      remainingRef.current = milliseconds;
      pendingRef.current = callback;
      pauseStartedRef.current = Date.now();

      timerRef.current = setTimeout(() => {
        if (session !== sessionRef.current) return;

        timerRef.current = null;

        if (pausedRef.current) return;

        pendingRef.current = null;
        remainingRef.current = 0;
        callback();
      }, milliseconds);
    }

    function speakSegment(index, local, base) {
      if (session !== sessionRef.current) return;

      if (index >= segments.length) {
        finish();
        return;
      }

      const segment = segments[index];
      const text = segment.words.slice(local).join(" ");

      if (!text) {
        speakSegment(index + 1, 0, base + segment.words.length);
        return;
      }

      const utterance = new SpeechSynthesisUtterance(text);

      const voice =
        segment.speaker === "host"
          ? voicesRef.current.host
          : voicesRef.current.guest;

      if (voice) {
        utterance.voice = voice;
        utterance.lang = voice.lang;
      } else {
        utterance.lang = "en-US";
      }

      utterance.rate = playbackSpeed;
      utterance.pitch = 1;
      utterance.volume = 1;

      utterance.onboundary = (event) => {
        if (session !== sessionRef.current) return;

        const spoken = text
          .slice(0, event.charIndex)
          .trim()
          .split(/\s+/)
          .filter(Boolean).length;

        const position = Math.min(
          totalWords,
          base + local + spoken
        );

        wordOffsetRef.current = position;
        setWordOffset(position);
      };

      utterance.onend = () => {
        if (session !== sessionRef.current) return;

        const nextBase = base + segment.words.length;

        wordOffsetRef.current = nextBase;
        setWordOffset(nextBase);

        waitThenContinue(
          segment.pause / playbackSpeed,
          () => speakSegment(index + 1, 0, nextBase)
        );
      };

      utterance.onerror = (event) => {
        if (session !== sessionRef.current) return;

        if (
          event.error === "canceled" ||
          event.error === "interrupted"
        ) {
          return;
        }

        playingRef.current = false;
        pausedRef.current = false;
        setIsPlaying(false);
        setIsPaused(false);
      };

      window.speechSynthesis.speak(utterance);
    }

    speakSegment(start.index, start.local, start.base);
  }

  function togglePlayback() {
    if (!("speechSynthesis" in window)) return;

    if (playingRef.current && !pausedRef.current) {
      pausedRef.current = true;

      if (timerRef.current !== null) {
        clearTimeout(timerRef.current);
        timerRef.current = null;

        remainingRef.current = Math.max(
          0,
          remainingRef.current -
            (Date.now() - pauseStartedRef.current)
        );
      } else {
        window.speechSynthesis.pause();
      }

      setIsPaused(true);
      return;
    }

    if (playingRef.current && pausedRef.current) {
      pausedRef.current = false;

      if (pendingRef.current) {
        const callback = pendingRef.current;
        const remaining = remainingRef.current;

        pauseStartedRef.current = Date.now();

        timerRef.current = setTimeout(() => {
          timerRef.current = null;

          if (pausedRef.current) return;

          pendingRef.current = null;
          remainingRef.current = 0;
          callback();
        }, remaining);
      } else {
        window.speechSynthesis.resume();
      }

      setIsPaused(false);
      return;
    }

    speakFrom(wordOffsetRef.current);
  }

  function skipSeconds(seconds) {
    const jump = Math.round(
      seconds * (145 / 60) * speedRef.current
    );

    const next = Math.max(
      0,
      Math.min(
        wordOffsetRef.current + jump,
        Math.max(0, totalWords - 1)
      )
    );

    if (playingRef.current) {
      speakFrom(next);
    } else {
      wordOffsetRef.current = next;
      setWordOffset(next);
    }
  }

  function changeSection(index) {
    stopSpeech();
    wordOffsetRef.current = 0;
    setWordOffset(0);
    setSelectedIndex(index);
  }

  function changeSpeed(nextSpeed) {
    const value = Number(nextSpeed);

    speedRef.current = value;
    setSpeed(value);

    if (playingRef.current) {
      speakFrom(wordOffsetRef.current, value);
    }
  }

  useEffect(() => {
    if (!("speechSynthesis" in window)) return;

    function updateVoices() {
      voicesRef.current = chooseVoices(
        window.speechSynthesis.getVoices()
      );
    }

    updateVoices();

    window.speechSynthesis.addEventListener?.(
      "voiceschanged",
      updateVoices
    );

    return () => {
      sessionRef.current += 1;

      if (timerRef.current !== null) {
        clearTimeout(timerRef.current);
      }

      window.speechSynthesis.cancel();

      window.speechSynthesis.removeEventListener?.(
        "voiceschanged",
        updateVoices
      );
    };
  }, []);

  const progress = totalWords
    ? (wordOffset / totalWords) * 100
    : 0;

  return (
    <main className="audio-policy-page">
      <header className="audio-policy-header">
        <p className="audio-policy-label">
          AUDIO PRIVACY PRESENTATION
        </p>

        <h1>Spotify Privacy Policy</h1>

        <p>
          Listen to the same ten privacy categories
          explained in the Visual and Text presentations.
        </p>
      </header>

      <section className="audio-player">
        <div className="audio-player-artwork">♫</div>

        <p className="audio-now-playing">
          NOW PLAYING · SECTION{" "}
          {String(selectedIndex + 1).padStart(2, "0")}
          {" "}OF {categories.length}
        </p>

        <h2>
          {selectedCategory?.title || "Privacy Policy"}
        </h2>

        <p className="audio-player-subtitle">
          Spotify Privacy Policy Explained
        </p>

        <div
          className="audio-progress-track"
          role="progressbar"
          aria-label="Approximate narration progress"
          aria-valuenow={Math.round(progress)}
          aria-valuemin={0}
          aria-valuemax={100}
        >
          <div
            className="audio-progress-fill"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="audio-progress-labels">
          <span>{Math.round(progress)}% complete</span>
          <span>Approximate progress</span>
        </div>

        <div className="audio-player-controls">
          <button
            type="button"
            className="audio-skip-button"
            onClick={() => skipSeconds(-10)}
            aria-label="Rewind approximately 10 seconds"
          >
            ↶ <span>10</span>
          </button>

          <button
            type="button"
            className="audio-play-button"
            onClick={togglePlayback}
          >
            {isPlaying && !isPaused
              ? "❚❚ Pause"
              : "▶ Play"}
          </button>

          <button
            type="button"
            className="audio-skip-button"
            onClick={() => skipSeconds(10)}
            aria-label="Forward approximately 10 seconds"
          >
            ↷ <span>10</span>
          </button>
        </div>

        <div className="audio-speed-control">
          <label htmlFor="audio-speed">
            Playback speed
          </label>

          <select
            id="audio-speed"
            value={speed}
            onChange={(event) =>
              changeSpeed(event.target.value)
            }
          >
            {SPEEDS.map((value) => (
              <option key={value} value={value}>
                {value}×
              </option>
            ))}
          </select>
        </div>
      </section>

      <section className="audio-section-list">
        <h2>Choose a Privacy Section</h2>

        <p>Select any section to hear its explanation.</p>

        <div className="audio-track-list">
          {categories.map((category, index) => (
            <button
              key={category.id || index}
              type="button"
              className={`audio-track ${
                selectedIndex === index
                  ? "audio-track-active"
                  : ""
              }`}
              onClick={() => changeSection(index)}
            >
              <span className="audio-track-number">
                {String(index + 1).padStart(2, "0")}
              </span>

              <span className="audio-track-title">
                {category.title}
              </span>

              <span className="audio-track-action">
                {selectedIndex === index
                  ? "Selected"
                  : "Listen →"}
              </span>
            </button>
          ))}
        </div>
      </section>

      <footer className="audio-policy-footer">
        <h2>Read the Original Privacy Policy</h2>

        <p>
          This audio explanation summarizes Spotify's
          privacy policy. Read the original for complete details.
        </p>

        <a
          href="https://www.spotify.com/us/legal/privacy-policy/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Read Spotify's Original Privacy Policy ↗
        </a>
      </footer>
    </main>
  );
}
