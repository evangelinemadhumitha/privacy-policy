
import { useState } from "react";
import "./OriginalPresentation.css";

const PDF_URL = `${import.meta.env.BASE_URL}spotify-policy.pdf`;

export default function OriginalPresentation() {
  const [zoom, setZoom] = useState(100);
  const [pdfError, setPdfError] = useState(false);

  function zoomIn() {
    setZoom((current) => Math.min(current + 25, 200));
  }

  function zoomOut() {
    setZoom((current) => Math.max(current - 25, 75));
  }

  function resetZoom() {
    setZoom(100);
  }

  return (
    <main className="original-policy-page">
      <header className="original-policy-header">
        <p className="original-policy-label">
          ORIGINAL PRIVACY PRESENTATION
        </p>

        <h1>Spotify Privacy Policy</h1>

        <p>
          Read the complete original Spotify Privacy Policy
          in PDF format.
        </p>
      </header>

      <section className="original-policy-document">
        <div className="original-policy-document-heading">
          <div className="original-policy-file-icon">
            📄
          </div>

          <div className="original-policy-file-info">
            <h2>Original Spotify Privacy Policy</h2>
            <p>Full document · 33 pages · PDF format</p>
          </div>
        </div>

        {/* PDF controls */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: "14px",
            marginBottom: "20px",
          }}
        >
          {/* Zoom controls */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "10px",
            }}
          >
            <button
              type="button"
              onClick={zoomOut}
              disabled={zoom <= 75}
              style={buttonStyle}
              aria-label="Zoom out"
            >
              −
            </button>

            <span
              style={{
                minWidth: "55px",
                textAlign: "center",
                fontWeight: 700,
                color: "#173b2b",
              }}
            >
              {zoom}%
            </span>

            <button
              type="button"
              onClick={zoomIn}
              disabled={zoom >= 200}
              style={buttonStyle}
              aria-label="Zoom in"
            >
              +
            </button>

            <button
              type="button"
              onClick={resetZoom}
              style={buttonStyle}
            >
              Reset
            </button>
          </div>

          {/* PDF actions */}
          <div
            style={{
              display: "flex",
              flexWrap: "wrap",
              gap: "10px",
            }}
          >
            <a
              href={PDF_URL}
              target="_blank"
              rel="noopener noreferrer"
              style={linkStyle}
            >
              ↗ Open PDF
            </a>

            <a
              href={PDF_URL}
              download="Spotify-Privacy-Policy.pdf"
              style={downloadStyle}
            >
              ↓ Download PDF
            </a>
          </div>
        </div>

        {/* Embedded PDF viewer */}
        <div
          className="original-policy-pdf-container"
          style={{
            overflow: "hidden",
            borderRadius: "12px",
            background: "#f3f5f3",
          }}
        >
          {pdfError ? (
            <div
              style={{
                padding: "40px 20px",
                textAlign: "center",
              }}
            >
              <h3>Unable to display the PDF</h3>

              <p>
                Please open the document in a new tab.
              </p>

              <a
                href={PDF_URL}
                target="_blank"
                rel="noopener noreferrer"
              >
                Open Spotify Privacy Policy
              </a>
            </div>
          ) : (
            <iframe
              key={zoom}
              src={`${PDF_URL}#toolbar=1&navpanes=0&zoom=${zoom}`}
              title="Original Spotify Privacy Policy PDF"
              className="original-policy-pdf"
              onError={() => setPdfError(true)}
              style={{
                display: "block",
                width: "100%",
                height: "800px",
                border: "none",
              }}
            />
          )}
        </div>

        <p
          style={{
            marginTop: "18px",
            fontSize: "13px",
            lineHeight: 1.7,
            color: "#718078",
          }}
        >
          This document contains Spotify's original
          Privacy Policy, effective July 1, 2026.
          Scroll through the PDF to read all 33 pages.
        </p>

        <a
          href="https://www.spotify.com/us/legal/privacy-policy/"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: "inline-block",
            marginTop: "10px",
            color: "#16834a",
            fontWeight: 600,
            textDecoration: "none",
          }}
        >
          View Spotify's Official Privacy Policy ↗
        </a>
      </section>
    </main>
  );
}

const buttonStyle = {
  padding: "10px 15px",
  borderRadius: "9px",
  border: "1px solid #d8e2dc",
  background: "#ffffff",
  color: "#173b2b",
  fontSize: "14px",
  fontWeight: 600,
  cursor: "pointer",
};

const linkStyle = {
  ...buttonStyle,
  display: "inline-flex",
  alignItems: "center",
  textDecoration: "none",
};

const downloadStyle = {
  ...linkStyle,
  background: "#16834a",
  color: "#ffffff",
  border: "1px solid #16834a",
};
